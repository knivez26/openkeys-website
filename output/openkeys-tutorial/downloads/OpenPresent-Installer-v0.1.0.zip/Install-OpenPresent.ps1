$ErrorActionPreference = 'Stop'

$appName = 'OpenPresent'
$appUrl = 'https://openpresent-ocr.darffv.chatgpt.site/'
$installRoot = Join-Path $env:LOCALAPPDATA 'OpenPresent'
$startMenu = Join-Path $env:APPDATA 'Microsoft\Windows\Start Menu\Programs'
$desktop = [Environment]::GetFolderPath('Desktop')

$browserCandidates = @(
    (Join-Path ${env:ProgramFiles(x86)} 'Microsoft\Edge\Application\msedge.exe'),
    (Join-Path $env:ProgramFiles 'Microsoft\Edge\Application\msedge.exe'),
    (Join-Path $env:LOCALAPPDATA 'Microsoft\Edge\Application\msedge.exe'),
    (Join-Path $env:ProgramFiles 'Google\Chrome\Application\chrome.exe'),
    (Join-Path ${env:ProgramFiles(x86)} 'Google\Chrome\Application\chrome.exe'),
    (Join-Path $env:LOCALAPPDATA 'Google\Chrome\Application\chrome.exe')
) | Where-Object { $_ -and (Test-Path -LiteralPath $_) }

if (-not $browserCandidates) {
    throw 'OpenPresent requires Microsoft Edge or Google Chrome.'
}

$browser = $browserCandidates[0]
New-Item -ItemType Directory -Force -Path $installRoot | Out-Null

$launcher = @"
@echo off
start "" "$browser" --app="$appUrl" --start-maximized
"@
Set-Content -LiteralPath (Join-Path $installRoot 'OpenPresent.cmd') -Value $launcher -Encoding Ascii

$shell = New-Object -ComObject WScript.Shell
foreach ($shortcutPath in @(
    (Join-Path $startMenu 'OpenPresent.lnk'),
    (Join-Path $desktop 'OpenPresent.lnk')
)) {
    $shortcut = $shell.CreateShortcut($shortcutPath)
    $shortcut.TargetPath = $browser
    $shortcut.Arguments = "--app=`"$appUrl`" --start-maximized"
    $shortcut.WorkingDirectory = $installRoot
    $shortcut.IconLocation = "$browser,0"
    $shortcut.Description = 'OpenPresent — OCR presentation maker'
    $shortcut.Save()
}

Write-Host ''
Write-Host 'OpenPresent was installed successfully.' -ForegroundColor Green
Write-Host 'It will open in a dedicated app window without browser tabs or an address bar.'
Write-Host ''
Start-Process -FilePath $browser -ArgumentList @("--app=$appUrl", '--start-maximized')
