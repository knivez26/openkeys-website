$ErrorActionPreference = 'Stop'
$targets = @(
    (Join-Path $env:LOCALAPPDATA 'OpenPresent'),
    (Join-Path $env:APPDATA 'Microsoft\Windows\Start Menu\Programs\OpenPresent.lnk'),
    (Join-Path ([Environment]::GetFolderPath('Desktop')) 'OpenPresent.lnk')
)
foreach ($target in $targets) {
    if (Test-Path -LiteralPath $target) {
        Remove-Item -LiteralPath $target -Recurse -Force
    }
}
Write-Host 'OpenPresent shortcuts and launcher were removed.' -ForegroundColor Green
